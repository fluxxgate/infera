# REVERSE ENGINEER

class re:
    def get_pid(pid: int):
        pass

    def get_source():
        pass