def main():
    print("Welcome to my_package!")
    # Add your main functionality here

if __name__ == "__main__":
    main()